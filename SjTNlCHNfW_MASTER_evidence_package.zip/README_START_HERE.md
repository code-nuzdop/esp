# SjTNlCHNfW — forensic analysis evidence package

Primary reading: report/SjTNlCHNfW_MASTER_comprehensive_report.pdf
Searchable/editable source: report/SjTNlCHNfW_MASTER_comprehensive_report.md

The ZIP contains the exhaustive 256-key opcode registry, 93 callback summaries,
124 typed VM locals, 43 final decoded reader records, full method inventories
for all 888 MethodDef rows, per-instruction IL for 650 file-backed MethodDefs,
call graph, CFG, helper audit, original static reader emulation scripts, and
historical reports whose outdated claims are superseded by the master report.

It intentionally excludes both original EXE copies, the paused 102 MB process
memory dump and user conversational pasted text, to avoid redistributing a
potentially dangerous executable or arbitrary process memory. The SHA-256
of the source EXE is 119883c62a2e832f0e9058e0d88e391f15820674cdd33d79845c73c58d63ea40.

All reports are static analyses; the original executable was not executed
when creating this package. Decoded traces are offline reconstructions, not
runtime call traces. Full protected application semantics remain unresolved.

Verify a bundled file by computing its SHA256 and comparing to MANIFEST_SHA256.txt.
